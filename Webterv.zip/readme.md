# Travel Agency 
##  Hiányzó elemek/ ideiglenes megoldások:
- Üzenetküldés sajnos nem funkciónál
 ## Tesztelés
- Adatbázissal lett megoldva:  MySQL
  - Username: root
  - Password: root
  - Host name: localhost
  - Leírás: MacOS-en dolgoztam a xampp nem működött esetemben, másik programmal dolgoztam, de ha jól tudom a php automatikusan megoldja a port számot, azzal nem kell foglalkozni.
  - Ha véletlenül az adatbázissal gond lenne, nem akar elindulni valami config fájl vagy valami miatt, akkor az alábbi emailen el tudtok érni: erosbalint3@gmail.com (de nem kellene probléma legyen)