# Travel Agency 
##  Hiányzó elemek/ ideiglenes megoldások:
 - Login oldalon a submit gomb egyenlőre csak átnavigál a kezdőoldalra, a tényleges bejelentkezés a 2. mérföldkőben lesz megvalósítva
 - Ugyanez igaz a regisztrációra, jelenleg még semmilyen validáció nincs, a tényleges adatmentés, stb. a php részében lesz implementálva
 - Profile menüpont egyenlőre mindig látszódik külön menüpont alatt, a második mérföldkőben, ha bejelentkezett a felhasználó, akkor a log in helyett lesz

 ## Tesztelés
  - Telefonon én live serverrel teszteltem ngrok-kal, de ha a teszteléskor használt hálózat támogatja a Lanozást, akkor IP cím alapján el lehet érni a weboldalat a telefonról is.
  