function login() {
    document.location.href = "index.html";
}